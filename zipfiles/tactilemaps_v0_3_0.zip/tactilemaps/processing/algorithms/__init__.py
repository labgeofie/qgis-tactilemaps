# -*- coding: utf-8 -*-
__copyright__ = '(C) 2023-2025 by Laboratorio de Geociencias - FIE'
__email__ = 'geociencias@fie.undef.edu.ar'
__license__ = 'GPL version 3'
